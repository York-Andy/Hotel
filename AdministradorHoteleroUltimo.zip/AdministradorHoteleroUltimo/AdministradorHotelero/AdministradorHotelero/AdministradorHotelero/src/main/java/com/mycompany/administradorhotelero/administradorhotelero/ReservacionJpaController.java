
package com.mycompany.administradorhotelero.administradorhotelero;

import com.mycompany.administradorhotelero.Entidades.Entidades.Reservacion;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;


public class ReservacionJpaController {
    private final EntityManagerFactory emf;
    public ReservacionJpaController(EntityManagerFactory emf) {
       this.emf=emf;
    }

    public ReservacionJpaController() {
        this.emf = Persistence.createEntityManagerFactory("entidadesJPAPU");
    }
    
    
    public EntityManager getEntityManager(){
    return emf.createEntityManager();
    
    }


    public void createReservacion(Reservacion reservacion) {
          EntityManager em =null;
     try{
     em = getEntityManager();
     em.getTransaction().begin();
     em.persist(reservacion);
     em.getTransaction().commit();
     }finally{
     if(em!=null){
     em.close();
     }
    }
    }

    public void destroytReserva(int ReservacionId)throws Exception {
       EntityManager em = null;
        try{
        em = getEntityManager();
        em.getTransaction().begin();
        Reservacion reserva;
        try{
        reserva=em.getReference(Reservacion.class, ReservacionId);
        reserva.getReservacionId();
        }catch (EntityNotFoundException enfe){
            throw new Exception("el hotel id "+ReservacionId+"no se encuentra habil o es inexistente ");
        }
        em.remove(reserva);
        em.getTransaction().commit();
        }finally{
        if(em!=null){
        em.close();
        }
        } 
    }

    public void editarReserva(Reservacion reserva)throws Exception {
      EntityManager em =null;
        try{
        em =getEntityManager();
        em.getTransaction().begin();
        reserva =em.merge(reserva);
        em.getTransaction().commit();
        }catch(Exception ex ){
        String msg =ex.getLocalizedMessage();
        if(msg == null ||msg.length()==0){
        int id =reserva.getReservacionId();
                  }
        
        }finally{
        if(em!=null){
        em.close();
        }
        }  
    }

    public Reservacion traerReservacion(int ReservacionId) {
         EntityManager em = getEntityManager(); // Obtiene el EntityManager
    try {
        return em.find(Reservacion.class, ReservacionId); // Utiliza el método find para buscar el hotel por su ID
    } catch (Exception ex) {
        // Manejar la excepción apropiadamente
        ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
        return null; // O devuelve un hotel nulo o lanza una excepción personalizada
    } finally {
        if (em != null && em.isOpen()) {
            em.close(); // Asegúrate de cerrar el EntityManager si está abierto
        }
    }
    }

    public List<Reservacion> listarReservacion() {
        return findReservacion(true,-1,-1);
    }

    private List<Reservacion> findReservacion(boolean all, int maximo, int minimo) {
         EntityManager em = getEntityManager(); // Obtener el EntityManager

        try {
            CriteriaQuery<Reservacion> cq = (CriteriaQuery<Reservacion>) em.getCriteriaBuilder().createQuery(Reservacion.class);
            Root<Reservacion> root = (Root<Reservacion>) cq.from(Reservacion.class);
            cq.select((Selection<? extends Reservacion>) root);

            if (!all) {
                // Si no es necesario obtener todos los hoteles, aplica paginación
                Query q = em.createQuery(cq);
                q.setMaxResults(maximo);
                q.setFirstResult(minimo);
                return q.getResultList();
            } else {
                // Si se necesitan todos los hoteles
                return em.createQuery(cq).getResultList();
            }
        } catch (Exception ex) {
            // Manejar la excepción apropiadamente
            ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
            return null; // O devuelve una lista vacía o lanza una excepción personalizada
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Asegúrate de cerrar el EntityManager si está abierto
            }
        }

    }
}
