
package ventanas;

import com.mycompany.administradorhotelero.Entidades.Entidades.Hotel;
import com.mycompany.administradorhotelero.administradorhotelero.UsuarioJpaController;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.EntityManager;
import com.mycompany.administradorhotelero.Entidades.Entidades.Usuario;
import com.mycompany.administradorhotelero.administradorhotelero.HotelJpaController;
import com.mycompany.administradorhotelero.administradorhotelero.UsuarioJpaController;
import com.mycompany.administradorhotelero.exceptions.NonexistentEntityException;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.persistence.Id;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
public class UsuarioII extends javax.swing.JFrame {
   
   public UsuarioII() {
       initComponents();
        
        jLsalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Salir de la aplicación
                System.exit(0);
            }
});
   // Configuración de la ventana
       setLocationRelativeTo(null);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       setSize(550, 500);
        
    }
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLsalir = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        idUsuariojt = new javax.swing.JTextField();
        nombrejt = new javax.swing.JTextField();
        apellidojt = new javax.swing.JTextField();
        nombreUsuariojt = new javax.swing.JTextField();
        roljt = new javax.swing.JTextField();
        emailjt = new javax.swing.JTextField();
        idHoteljt = new javax.swing.JTextField();
        passwordPasword = new javax.swing.JPasswordField();
        jbcreate = new javax.swing.JButton();
        jbdestroy = new javax.swing.JButton();
        jbeditar = new javax.swing.JButton();
        jblistar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLsalir.setBackground(new java.awt.Color(0, 0, 255));
        jLsalir.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLsalir.setForeground(new java.awt.Color(0, 0, 0));
        jLsalir.setText("SALIR");
        getContentPane().add(jLsalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 10, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("ID_USUARIO :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("NOMBRE COMPLETO:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("APELLIDO :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("NOMBRE_USUARIO:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("PASSWORD:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("EMAIL:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("ROL EN HOTEL:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("HOTEL_ID:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));

        idUsuariojt.setBackground(new java.awt.Color(153, 153, 255));
        idUsuariojt.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(idUsuariojt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, 200, -1));

        nombrejt.setBackground(new java.awt.Color(153, 153, 255));
        getContentPane().add(nombrejt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 200, -1));

        apellidojt.setBackground(new java.awt.Color(153, 153, 255));
        apellidojt.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(apellidojt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 120, 200, -1));

        nombreUsuariojt.setBackground(new java.awt.Color(153, 153, 255));
        nombreUsuariojt.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(nombreUsuariojt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 200, -1));

        roljt.setBackground(new java.awt.Color(153, 153, 255));
        roljt.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(roljt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 280, 200, -1));

        emailjt.setBackground(new java.awt.Color(153, 153, 255));
        emailjt.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(emailjt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 240, 200, -1));

        idHoteljt.setBackground(new java.awt.Color(153, 153, 255));
        idHoteljt.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(idHoteljt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 320, 200, -1));

        passwordPasword.setBackground(new java.awt.Color(153, 153, 255));
        passwordPasword.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(passwordPasword, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 200, 200, -1));

        jbcreate.setBackground(new java.awt.Color(153, 153, 255));
        jbcreate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jbcreate.setForeground(new java.awt.Color(0, 0, 0));
        jbcreate.setText("CREATE");
        jbcreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbcreateActionPerformed(evt);
            }
        });
        getContentPane().add(jbcreate, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, -1, -1));

        jbdestroy.setBackground(new java.awt.Color(153, 153, 255));
        jbdestroy.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jbdestroy.setForeground(new java.awt.Color(0, 0, 0));
        jbdestroy.setText("DESTROY");
        jbdestroy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbdestroyActionPerformed(evt);
            }
        });
        getContentPane().add(jbdestroy, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 390, -1, -1));

        jbeditar.setBackground(new java.awt.Color(153, 153, 255));
        jbeditar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jbeditar.setForeground(new java.awt.Color(0, 0, 0));
        jbeditar.setText("EDITAR");
        jbeditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbeditarActionPerformed(evt);
            }
        });
        getContentPane().add(jbeditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 390, -1, -1));

        jblistar.setBackground(new java.awt.Color(153, 153, 255));
        jblistar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jblistar.setForeground(new java.awt.Color(0, 0, 0));
        jblistar.setText("LISTAR");
        jblistar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jblistarActionPerformed(evt);
            }
        });
        getContentPane().add(jblistar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 390, -1, -1));

        jLabel11.setBackground(new java.awt.Color(255, 0, 204));
        jLabel11.setForeground(new java.awt.Color(0, 204, 204));
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Fotos/Imagen/usuario.png"))); // NOI18N
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 130, 100, 110));

        jLabel1.setForeground(new java.awt.Color(153, 153, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Fotos/Imagen/FondoPantalla.jpg"))); // NOI18N
        jLabel1.setText("JLabelFondo");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 564, 453));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbcreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbcreateActionPerformed
      
    }//GEN-LAST:event_jbcreateActionPerformed
//------------------------------------------------------------------------------------
    private void jbdestroyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbdestroyActionPerformed
            // Obtener el ID ingresado por el usuario
    int Id = Integer.parseInt(idUsuariojt.getText());

    // Crear una instancia de EntityManagerFactory
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("entidadesJPAPU");

    // Crear una instancia de UsuarioJpaController pasando EntityManagerFactory
    UsuarioJpaController usuarioController = new UsuarioJpaController(emf);

    EntityManager em = null; // Declaración fuera del bloque try

    try {
        // Obtener el EntityManager
        em = emf.createEntityManager();

        // Comenzar una transacción
        em.getTransaction().begin();

        // Eliminar el usuario con el ID especificado
        usuarioController.destroyUsuario(Id);

        // Confirmar la transacción
        em.getTransaction().commit();
        // Notificar al usuario que se ha eliminado correctamente
        JOptionPane.showMessageDialog(null, "Usuario eliminado exitosamente");

    
    } catch (Exception ex) {
        // Manejar la excepción apropiadamente
        JOptionPane.showMessageDialog(null, "Error al eliminar usuario: " + ex.getMessage());
    } finally {
        // Cerrar el EntityManager si no es nulo y está abierto
        if (em != null && em.isOpen()) {
            em.close();
        }
    }

    // Limpiar el campo de texto del ID del usuario
    idUsuariojt.setText("");

        
    }//GEN-LAST:event_jbdestroyActionPerformed
//-----------------------------------------------------------------------------------
    private void jbeditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbeditarActionPerformed
    try {
        // Obtener el ID del usuario que se desea editar
        int idUsuario = Integer.parseInt(idUsuariojt.getText());

        // Crear una instancia de EntityManagerFactory
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("entidadesJPAPU");

        // Crear una instancia de UsuarioJpaController pasando EntityManagerFactory
        UsuarioJpaController usuarioController = new UsuarioJpaController(emf);

        // Traer el usuario de la base de datos utilizando su ID
        Usuario usuario = usuarioController.traerUsuario(idUsuario);

        if (usuario != null) {
            // Obtener los nuevos valores de los campos de texto u otros componentes de la vista
            String nombre = nombrejt.getText();
            String apellido = apellidojt.getText();
            String nombreDeUsuario = nombreUsuariojt.getText();
            String email = emailjt.getText();
            String rolEnHotel = roljt.getText();
            String idHotel = idHoteljt.getText(); // Asumiendo que este campo representa el ID del hotel

            // Actualizar los valores del usuario con los nuevos valores
            usuario.setNombre(nombre);
            usuario.setApellido(apellido);
            usuario.setNombreDeUsuario(nombreDeUsuario);
            usuario.setEmail(email);
            usuario.setRolEnHotel(rolEnHotel);

            // Verificar si el campo ID del hotel no está vacío
            if (!idHotel.isEmpty()) {
                // Crear una instancia de HotelJpaController pasando EntityManagerFactory
                HotelJpaController hotelController = new HotelJpaController(emf);

                // Obtener el hotel de la base de datos utilizando su ID
                try {
                    Hotel hotel = hotelController.findHotel(Integer.parseInt(idHotel));

                    // Asignar el hotel al usuario si se encontró
                    if (hotel != null) {
                        usuario.setHotel(hotel);
                    } else {
                        // Mostrar un mensaje de error si no se encontró el hotel
                        JOptionPane.showMessageDialog(null, "El hotel con el ID proporcionado no fue encontrado");
                        return; // Salir del método sin continuar con la edición
                    }
                } catch (NumberFormatException ex) {
                    // Manejar el caso donde el ID del hotel no es un número válido
                    JOptionPane.showMessageDialog(null, "El ID del hotel no es válido");
                    return; // Salir del método sin continuar con la edición
                }
            }

            // Llamar al método editarUsuario del controlador para guardar los cambios
            try {
                usuarioController.editarUsuario(usuario);

                // Notificar al usuario que la edición se realizó con éxito
                JOptionPane.showMessageDialog(null, "Usuario editado exitosamente");

                // Limpiar los campos de texto u otros componentes si es necesario
                limpiarCampos();
            } catch (Exception ex) {
                // Manejar cualquier excepción que pueda ocurrir durante la edición del usuario
                JOptionPane.showMessageDialog(null, "Error al editar usuario: " + ex.getMessage());
            }
        } else {
            // Notificar al usuario que el usuario no fue encontrado
            JOptionPane.showMessageDialog(null, "El usuario con el ID proporcionado no fue encontrado");
        }
    } catch (NumberFormatException ex) {
        // Manejar el caso donde el ID del usuario no es un número válido
        JOptionPane.showMessageDialog(null, "El ID del usuario no es válido");
    }
    }

// Método para limpiar los campos de texto u otros componentes
private void limpiarCampos() {
    
    nombrejt.setText("");
    apellidojt.setText("");
    nombreUsuariojt.setText("");
    emailjt.setText("");
    roljt.setText("");
    idHoteljt.setText("");
    }//GEN-LAST:event_jbeditarActionPerformed
//-------------------------------------------------------------------------------------
    private void jblistarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jblistarActionPerformed
    /*   if (tablaUsuario.isVisible()) {
        tablaUsuario.toFront(); // Si ya está visible, llevar al frente
    } else {
         UsuarioII usuarioII = new UsuarioII(); // Crear una instancia de UsuarioII
        usuarioII.add(tablaUsuario); // Agregar la instancia al contenedor UsuarioII
        tablaUsuario.setVisible(true); // Hacer visible la ventana interna
    }
    */}//GEN-LAST:event_jblistarActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UsuarioII.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UsuarioII.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UsuarioII.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UsuarioII.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
             new UsuarioII().setVisible(true);
            }
        });
    }
   /* public static void mostrarVentanaPrincipal(EntityManagerFactory emf) {
       // Crear una instancia de la ventana principal UsuarioII
       UsuarioII ventanaPrincipal = new UsuarioII();
       // Hacer visible la ventana principal
       ventanaPrincipal.setVisible(true);
   }*/
  


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField apellidojt;
    private javax.swing.JTextField emailjt;
    private javax.swing.JTextField idHoteljt;
    private javax.swing.JTextField idUsuariojt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLsalir;
    private javax.swing.JButton jbcreate;
    private javax.swing.JButton jbdestroy;
    private javax.swing.JButton jbeditar;
    private javax.swing.JButton jblistar;
    private javax.swing.JTextField nombreUsuariojt;
    private javax.swing.JTextField nombrejt;
    private javax.swing.JPasswordField passwordPasword;
    private javax.swing.JTextField roljt;
    // End of variables declaration//GEN-END:variables
}
