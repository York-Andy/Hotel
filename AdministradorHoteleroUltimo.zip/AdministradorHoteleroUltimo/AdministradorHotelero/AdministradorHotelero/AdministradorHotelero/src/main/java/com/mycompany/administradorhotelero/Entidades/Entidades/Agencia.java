
package com.mycompany.administradorhotelero.Entidades.Entidades;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
@Entity
@Table(name="Agencia")
@Data

public class Agencia implements Serializable{
  private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="Id")
    private long Id;
    
    @Column(name="kind")
    private String kind;
    
    @Column(name="Titulo")
    private String Titulo;
    
    @Column(name="AdministradorContable")
    private String AdministradorContable;
    
    @Column(name="NumeroImpuestos")
    private String NumeroImpuestos;
    
    @Column(name="Provincia")
    private String Provincia;
    
    @Column(name="Cuidad")
    private String Cuidad;
    
    @Column(name="email")
    private String email;
    
    @Column(name="Direccion")
    private String Direccion;
    
    @Column(name="Telefono")
    private String Telefono;
    
    @Column(name="NumeroColor")
    private int NumeroColor;
    
    @Column(name="FuncionalStatus")
    private boolean FuncionalStatus;

    public Agencia() {
    }

    public Agencia(long Id, String kind, String Titulo, String AdministradorContable, String NumeroImpuestos, String Provincia, String Cuidad, String email, String Direccion, String Telefono, int NumeroColor, boolean FuncionalteStatus) {
        this.Id = Id;
        this.kind = kind;
        this.Titulo = Titulo;
        this.AdministradorContable = AdministradorContable;
        this.NumeroImpuestos = NumeroImpuestos;
        this.Provincia = Provincia;
        this.Cuidad = Cuidad;
        this.email = email;
        this.Direccion = Direccion;
        this.Telefono = Telefono;
        this.NumeroColor = NumeroColor;
        this.FuncionalStatus = FuncionalStatus;
    }

    public Agencia(String kind, String Titulo, String AdministradorContable, String NumeroImpuestos, String Provincia, String Cuidad, String email, String Direccion, String Telefono, int NumeroColor, boolean FuncionalteStatus) {
        this.kind = kind;
        this.Titulo = Titulo;
        this.AdministradorContable = AdministradorContable;
        this.NumeroImpuestos = NumeroImpuestos;
        this.Provincia = Provincia;
        this.Cuidad = Cuidad;
        this.email = email;
        this.Direccion = Direccion;
        this.Telefono = Telefono;
        this.NumeroColor = NumeroColor;
        this.FuncionalStatus = FuncionalStatus;
    }
@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (Id ^ (Id >>> 32));
		result = prime * result + (FuncionalStatus? 1231 : 1237);
		result = prime * result + ((Direccion == null) ? 0 : Direccion.hashCode());
		result = prime * result + ((Provincia == null) ? 0 : Provincia.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + (NumeroColor^ (NumeroColor >>> 32));
		result = prime * result + ((kind == null) ? 0 : kind.hashCode());
		result = prime * result + ((Telefono == null) ? 0 : Telefono.hashCode());
		result = prime * result + ((Cuidad == null) ? 0 : Cuidad.hashCode());
		result = prime * result + ((AdministradorContable== null) ? 0 : AdministradorContable.hashCode());
		result = prime * result + ((NumeroImpuestos == null) ? 0 : NumeroImpuestos.hashCode());
		result = prime * result + ((Titulo == null) ? 0 : Titulo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Agencia other = (Agencia) obj;
		if (Id != other.Id)
			return false;
		if (FuncionalStatus != other.FuncionalStatus)
			return false;
		if (Direccion == null) {
			if (other.Direccion!= null)
				return false;
		} else if (!Direccion.equals(other.Direccion))
			return false;
		if (Cuidad == null) {
			if (other.Cuidad != null)
				return false;
		} else if (!Cuidad.equals(other.Cuidad))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (NumeroColor != other.NumeroColor) {
				return false;
		}
		if (kind == null) {
			if (other.kind != null)
				return false;
		} else if (!kind.equals(other.kind))
			return false;
		if (Telefono == null) {
			if (other.Telefono != null)
				return false;
		} else if (!Telefono.equals(other.Telefono))
			return false;
		if (Provincia == null) {
			if (other.Provincia != null)
				return false;
		} else if (!Provincia.equals(other.Provincia))
			return false;
		if (AdministradorContable == null) {
			if (other.AdministradorContable != null)
				return false;
		} else if (!AdministradorContable.equals(other.AdministradorContable))
			return false;
		if (NumeroImpuestos == null) {
			if (other.NumeroImpuestos != null)
				return false;
		} else if (!NumeroImpuestos.equals(other.NumeroImpuestos))
			return false;
		if (Titulo == null) {
			if (other.Titulo!= null)
				return false;
		} else if (!Titulo.equals(other.Titulo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Agencia [Id=" + Id + ", kind=" + kind + ", Titulo=" + Titulo+ ", AdministradorContable=" + AdministradorContable
				+ ", NumeroImpuestos=" + NumeroImpuestos + ", Provincia=" + Provincia + ", Cuidad=" + Cuidad + ", email=" + email
				+ ", Direccion=" + Direccion + ", Telefono=" + Telefono + ", NumeroColor=" + NumeroColor
				+ ", FuncionalStatus=" + FuncionalStatus + "]";
	}

    public  long getId() {
        return  Id;
    }

  
}
