

package com.mycompany.administradorhotelero.administradorhotelero;

import com.lowagie.text.Image;
import com.mycompany.administradorhotelero.Entidades.Entidades.Hotel;
import javax.swing.text.html.ImageView;




public class AdministradorHotelero {

    public static void main(String[] args) {
       ControladoraDePersistencia CDP =new ControladoraDePersistencia(); 
       //Image fotos =new Image(getClass().getResourceAsStream("/Fotos/foto.jpg"));
       //ImageView imag =new ImageView(fotos);
      // Hotel hotel =new Hotel("Rosal", 4, imag, "falcon", 01166707202, "Aregentina", "femenino", 47, "billinghust", "hotel familiar habitaciones modestas pero muy pulcras ", "salta 1257", "semana santa ");
    }
}
