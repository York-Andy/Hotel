
package com.mycompany.administradorhotelero.administradorhotelero;

import com.mycompany.administradorhotelero.Entidades.Entidades.Agencia;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;


public class AgenciaJpaController implements Serializable{
    private final EntityManagerFactory emf ;
    
     public AgenciaJpaController(EntityManagerFactory emf) {
       this.emf=emf;
    }
    
    public AgenciaJpaController() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("entidadesJPAPU");
        this.emf = emf;
        
        
    }
     public EntityManager getEntityManager(){
    return emf.createEntityManager();
    
    }

     public void createAgencia (Agencia agencia){
     EntityManager em =null;
     try{
     em = getEntityManager();
     em.getTransaction().begin();
     em.persist(agencia);
     em.getTransaction().commit();
     }finally{
     if(em!=null){
     em.close();
     }
     
     }}

    public void destroyAgencia(long Id)throws Exception {
        EntityManager em = null;
        try{
        em = getEntityManager();
        em.getTransaction().begin();
        Agencia agencia;
        try{
        agencia=em.getReference(Agencia.class, Id);
        agencia.getId();
        }catch (EntityNotFoundException enfe){
            throw new Exception("La agencia con  id "+Id+"no se encuentra habil o es inexistente ");
        }
        em.remove(agencia);
        em.getTransaction().commit();
        }finally{
        if(em!=null){
        em.close();
        }
    }
    }

    public void editarAgencia(Agencia agencia)throws Exception {
        EntityManager em =null;
        try{
        em =getEntityManager();
        em.getTransaction().begin();
        agencia =em.merge(agencia);
        em.getTransaction().commit();
        }catch(Exception ex ){
        String msg =ex.getLocalizedMessage();
        if(msg == null ||msg.length()==0){
        long Id =agencia.getId();
                  }
        
        }finally{
        if(em!=null){
        em.close();
        }
        }

    }

    Agencia traerAgencia(long Id) {
         EntityManager em = getEntityManager(); // Obtiene el EntityManager
    try {
        return em.find(Agencia.class, Id); // Utiliza el método find para buscar el Agenciapor su ID
    } catch (Exception ex) {
        // Manejar la excepción apropiadamente
        ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
        return null; // O devuelve un hotel nulo o lanza una excepción personalizada
    } finally {
        if (em != null && em.isOpen()) {
            em.close(); // Asegúrate de cerrar el EntityManager si está abierto
        }
    }
    }

    List<Agencia> listarAgencia() {
        return listarAgencias(true, -1, -1);
    }

    private List<Agencia> listarAgencias(boolean all, int maximo, int minimo) {
        EntityManager em = getEntityManager(); // Obtener el EntityManager

        try {
            CriteriaQuery<Agencia> cq = (CriteriaQuery<Agencia>) em.getCriteriaBuilder().createQuery(Agencia.class);
            Root<Agencia> root = (Root<Agencia>) cq.from(Agencia.class);
            cq.select((Selection<? extends Agencia>) root);

            if (!all) {
                // Si no es necesario obtener todos los hoteles, aplica paginación
                Query q = em.createQuery(cq);
                q.setMaxResults(maximo);
                q.setFirstResult(minimo);
                return q.getResultList();
            } else {
                // Si se necesitan todos los hoteles
                return em.createQuery(cq).getResultList();
            }
        } catch (Exception ex) {
            // Manejar la excepción apropiadamente
            ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
            return null; // O devuelve una lista vacía o lanza una excepción personalizada
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Asegúrate de cerrar el EntityManager si está abierto
            }
        }
 
    }
     
     
}
