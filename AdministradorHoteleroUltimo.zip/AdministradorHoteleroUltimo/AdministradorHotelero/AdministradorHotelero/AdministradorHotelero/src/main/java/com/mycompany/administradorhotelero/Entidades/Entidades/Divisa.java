
package com.mycompany.administradorhotelero.Entidades.Entidades;

import java.io.Serializable;
import lombok.Data;

@Data
public class Divisa implements Serializable{
 
	private Object base;
	private Object Fecha;
	private Object Tarifa;

    public Divisa() {
    }

    public Divisa(Object base, Object Fecha, Object Tarifa) {
        this.base = base;
        this.Fecha = Fecha;
        this.Tarifa = Tarifa;
    }
    @Override
	public String toString() {
		return "Divisa [base=" + base + ", Fecha=" + Fecha + ", Tarifa=" + Tarifa + "]";
	}

}
