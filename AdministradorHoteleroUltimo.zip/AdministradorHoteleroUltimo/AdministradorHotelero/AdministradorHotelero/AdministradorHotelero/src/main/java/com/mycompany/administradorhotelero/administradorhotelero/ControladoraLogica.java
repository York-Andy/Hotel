
package com.mycompany.administradorhotelero.administradorhotelero;

import com.mycompany.administradorhotelero.administradorhotelero.ControladoraDePersistencia;
import com.mycompany.administradorhotelero.Entidades.Entidades.Cliente;
import com.mycompany.administradorhotelero.Entidades.Entidades.Agencia;
import com.mycompany.administradorhotelero.Entidades.Entidades.Habitacion;
import com.mycompany.administradorhotelero.Entidades.Entidades.Hotel;
import com.mycompany.administradorhotelero.Entidades.Entidades.Pago;
import com.mycompany.administradorhotelero.Entidades.Entidades.StatusHotelero;
import com.mycompany.administradorhotelero.Entidades.Entidades.Usuario;
import java.util.List;
import com.mycompany.administradorhotelero.Entidades.Entidades.Reservacion;
public class ControladoraLogica {
  ControladoraDePersistencia  controlPersistencia =new ControladoraDePersistencia();
  public void createH (Hotel hotel){
  controlPersistencia.crearteH(hotel);
  }
  public void destroyH (int id){
  controlPersistencia.destroyH(id);
  }
  public void editarH (Hotel hote){
  controlPersistencia.editarH(hote);
  }
  public Hotel traerHotel(int id){
  return controlPersistencia.TraerHotel(id);
  }
  public List<Hotel>traerListahoteles(){
   return controlPersistencia.traerListahoteles();
  }
  //-----------------------------------------------------
  // Status hotelero
  //------------------------------------------------------
  public void createHS(StatusHotelero statushotelero){
  controlPersistencia.createHS(statushotelero);
  
  }
  public void destroyHS(int Id){
  controlPersistencia.destroyHS(Id);
  }
  public void editarHS(StatusHotelero statushotelero){
  controlPersistencia.editarHS(statushotelero);
  }
  public StatusHotelero TraerStatusHotelero(long Id){
   return controlPersistencia.TraerStatusHotelero(Id);
  }
  public List<StatusHotelero>traerListaStatusH(){
   return controlPersistencia.traerListaStatusH();
  }
  //-------------------------------------------------------------
  //Agencia
  //-------------------------------------
  public void createAgencia(Agencia agencia ){
  controlPersistencia.createAgencia(agencia);
  }
  public void destroyAgencia(long Id){
  controlPersistencia.destroyAgencia(Id);
  }
  public void editarAgencia(Agencia agencia){
  controlPersistencia.editarAgencia(agencia);
  }
  public Agencia traerAgencia(long Id){
  return controlPersistencia.traerAgencia(Id);
  }
  public List <Agencia>listarAgencia(){
  return controlPersistencia.listarAgencia();
  }
  //----------------------------------------------------------
  //Cliente
  //---------------------------------------------------------
  public void createCliente(Cliente cliente){
   controlPersistencia.createCliente(cliente);
  }
  public void destroyCliente(int UsuarioId){
   controlPersistencia.destroyCliente(UsuarioId);
  }
  public void editarCliente(Cliente cliente){
   controlPersistencia.editarCliente(cliente);
  }
  public Cliente traerCliente(int UsuarioId){
  return controlPersistencia.traerCliente(UsuarioId);
  }
  public List<Cliente>listarCliente(){
  return controlPersistencia.listarCliente();
  }
  //---------------------------------------------------------
  //Pago
  //--------------------------------------------------
  public void createPago(Pago pago){
  controlPersistencia.createPago(pago);
  }
  public void destroyPago(int IdPago){
  controlPersistencia.destroyPago(IdPago);
  }
  public void editarPago(Pago pago){
  controlPersistencia.editarPago(pago);
  }
  public Pago traerPago(int IdPago){
  return controlPersistencia.traerPago(IdPago);
  }
  public List<Pago>listarPago(){
  return controlPersistencia.listarPago();
  }
  //-------------------------------------------------------------
  //Habitacion
  //-----------------------------------------------------------
  public void createHabitacion(Habitacion habitacion){
  controlPersistencia.createHabitacion(habitacion);
  }
  public void destroytHabitacion(int IdHabitacion){
  controlPersistencia.destroytHabitacion(IdHabitacion);
  }
  public void editarHabitacion(Habitacion habitacion){
  controlPersistencia.editarHabitacion(habitacion);
  }
  public Habitacion traerHabitacion(int IdHabitacion){
  return controlPersistencia.traerHabitacion(IdHabitacion);
     
  }
  public List<Habitacion>ListarHabitacion(){
  return controlPersistencia.listarHabitacion();
  }
  //---------------------------------------------------------
  //Usuario
  //----------------------------------------------------------
  public void createUsuario(Usuario usuario){
  controlPersistencia.createUsuario(usuario);
  }
  public void destroytUsuario(int Id){
  controlPersistencia.destroytUsuario(Id);
  }
  public void editarUsuario(Usuario usuario){
  controlPersistencia.editarUsuario(usuario);
  }
  public Usuario traerUsuario(int Id){
  return controlPersistencia.traerUsuario(Id);
  }
  public List<Usuario>ListarUsuario(){
  return controlPersistencia.listarUsuario();
  }
  //-----------------------------------------
  //Reservacion
  //--------------------------------------
    public void createReserva(Reservacion reservacion){
    controlPersistencia.createReservacion( reservacion);
    }
    public void destroytReserva(int ReservacionId){
    controlPersistencia.destroytReserva(ReservacionId);
    }
    public void editarReserva(Reservacion reserva){
    controlPersistencia.editarReserva(reserva);
    }
    public Reservacion traerReservacion(int ReservacionId){
    return controlPersistencia.traerReservacion(ReservacionId);
    }
    public List<Reservacion>listarReservacion(){
    return controlPersistencia.ListarReservacion();
    }
   }
