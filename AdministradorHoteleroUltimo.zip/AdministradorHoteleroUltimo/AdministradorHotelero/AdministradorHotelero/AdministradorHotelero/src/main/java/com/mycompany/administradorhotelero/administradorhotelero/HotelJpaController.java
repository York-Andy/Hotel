
package com.mycompany.administradorhotelero.administradorhotelero;

import com.mycompany.administradorhotelero.Entidades.Entidades.Hotel;
import com.mycompany.administradorhotelero.Entidades.Entidades.StatusHotelero;
import jakarta.persistence.criteria.Root;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Selection;
import javax.swing.JOptionPane;


public class HotelJpaController implements Serializable{
    private final EntityManagerFactory emf;
     
    public HotelJpaController(EntityManagerFactory emf) {
       this.emf=emf;
    }

    public HotelJpaController() {
        this.emf = Persistence.createEntityManagerFactory("entidadesJPAPU");
    }
    
    
    public EntityManager getEntityManager(){
    return emf.createEntityManager();
    
    }

    public void createH(Hotel hotel) {
        EntityManager em =null;
     try{
     em = getEntityManager();
     em.getTransaction().begin();
     em.persist(hotel);
     em.getTransaction().commit();
     }finally{
     if(em!=null){
     em.close();
     }
    }
    }

   
    public void destroyH(int id) throws Exception{
        EntityManager em = null;
        try{
        em = getEntityManager();
        em.getTransaction().begin();
        Hotel hotel;
        try{
        hotel=em.getReference(Hotel.class, id);
        hotel.getId();
        }catch (EntityNotFoundException enfe){
            throw new Exception("el hotel id "+id+"no se encuentra habil o es inexistente ");
        }
        em.remove(hotel);
        em.getTransaction().commit();
        }finally{
        if(em!=null){
        em.close();
        }
        }
    }

    public void editarH(Hotel hote) throws Exception{
        EntityManager em =null;
        try{
        em =getEntityManager();
        em.getTransaction().begin();
        hote =em.merge(hote);
        em.getTransaction().commit();
        }catch(Exception ex ){
        String msg =ex.getLocalizedMessage();
        if(msg == null ||msg.length()==0){
        int id =hote.getId();
                  }
        
        }finally{
        if(em!=null){
        em.close();
        }
        }
    }

   public Hotel findHotel(int id) {
    EntityManager em = getEntityManager(); // Obtiene el EntityManager
    try {
        return em.find(Hotel.class, id); // Utiliza el método find para buscar el hotel por su ID
    } catch (Exception ex) {
        // Manejar la excepción apropiadamente
        ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
        return null; // O devuelve un hotel nulo o lanza una excepción personalizada
    } finally {
        if (em != null && em.isOpen()) {
            em.close(); // Asegúrate de cerrar el EntityManager si está abierto
        }
    }
}


   public List<Hotel> findListaHoteles() {
    return findHotel(true, -1, -1);
}

private List<Hotel> findHotel(boolean all, int maximo, int minimo) {
    EntityManager em = getEntityManager(); // Obtener el EntityManager

    try {
        CriteriaBuilder cb = em.getCriteriaBuilder(); // Obtener el CriteriaBuilder
        CriteriaQuery<Hotel> cq = cb.createQuery(Hotel.class); // Crear una CriteriaQuery para Hotel
        javax.persistence.criteria.Root<Hotel> root = cq.from(Hotel.class); // Obtener el Root para Hotel
        cq.select(root);

        if (!all) {
            // Si no es necesario obtener todos los hoteles, aplica paginación
            TypedQuery<Hotel> q = em.createQuery(cq);
            q.setMaxResults(maximo);
            q.setFirstResult(minimo);
            return q.getResultList();
        } else {
            // Si se necesitan todos los hoteles
            return em.createQuery(cq).getResultList();
        }
    } catch (Exception ex) {
        // Manejar la excepción apropiadamente
        ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
        return null; // O devuelve una lista vacía o lanza una excepción personalizada
    } finally {
        if (em != null && em.isOpen()) {
            em.close(); // Asegúrate de cerrar el EntityManager si está abierto
        }
    }
} 


}

  
    
    

