
package com.mycompany.administradorhotelero.Entidades.Entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
@Entity
@Table(name="Cliente")
@Data

public class Cliente implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="UsuarioId")
    private int UsuarioId;
    
    @Column(name="PrimerNombre")
    private String PrimerNombre;
    
    @Column(name="Apellido")
    private String Apellido;
    
    @Column(name="Pais")
    private String Pais;
    
    @Column(name="Documento")
    private String Documento;
    
    @Column(name="DocumentNro")
    private String DocumentNro;
    
    @Column(name="FechaNacimiento")
    private Date Fechanacimiento;
    
    @Column(name="Edad")
    private String Edad;
    
    @Column(name="Estadocivil")
    private String Estadocivil;
    
    @Column(name="ApellidoPaterno")
    private String ApellidoPaterno;
    
    @Column(name="ApellidoMaterno")
    private String ApellidoMaterno;
    
    @Column(name="Email")
    private String Email;
    
    @Column(name="Telefono")
    private String Telefono;
    
    @ManyToOne
    @JoinColumn(name = "ReservacionId", referencedColumnName = "ReservacionId") 
    private Reservacion reservacion;

    // Relación con Habitacion
    @ManyToOne
    @JoinColumn(name = "HabitacionId", referencedColumnName = "IdHabitacion") 
    private Habitacion habitacion;
    
    // Relación con Pago
    @ManyToOne
    @JoinColumn(name = "PagoId", referencedColumnName = "IdPago") 
    private Pago pago;

    public Cliente() {
    }

    public Cliente(int UsuarioId, String PrimerNombre, String Apellido, String Pais, String Documento, String DocumentNro, Date Fechanacimiento, String Edad, String Estadocivil, String ApellidoPaterno, String ApellidoMaterno, String Email, String Telefono, Reservacion reservacion, Habitacion habitacion, Pago pago) {
        this.UsuarioId = UsuarioId;
        this.PrimerNombre = PrimerNombre;
        this.Apellido = Apellido;
        this.Pais = Pais;
        this.Documento = Documento;
        this.DocumentNro = DocumentNro;
        this.Fechanacimiento = Fechanacimiento;
        this.Edad = Edad;
        this.Estadocivil = Estadocivil;
        this.ApellidoPaterno = ApellidoPaterno;
        this.ApellidoMaterno = ApellidoMaterno;
        this.Email = Email;
        this.Telefono = Telefono;
        this.reservacion = reservacion;
        this.habitacion = habitacion;
        this.pago = pago;
    }

    public Cliente(String PrimerNombre, String Apellido, String Pais, String Documento, String DocumentNro, Date Fechanacimiento, String Edad, String Estadocivil, String ApellidoPaterno, String ApellidoMaterno, String Email, String Telefono, Reservacion reservacion, Habitacion habitacion, Pago pago) {
        this.PrimerNombre = PrimerNombre;
        this.Apellido = Apellido;
        this.Pais = Pais;
        this.Documento = Documento;
        this.DocumentNro = DocumentNro;
        this.Fechanacimiento = Fechanacimiento;
        this.Edad = Edad;
        this.Estadocivil = Estadocivil;
        this.ApellidoPaterno = ApellidoPaterno;
        this.ApellidoMaterno = ApellidoMaterno;
        this.Email = Email;
        this.Telefono = Telefono;
        this.reservacion = reservacion;
        this.habitacion = habitacion;
        this.pago = pago;
    }
   
        
   @Override
	public String toString() {
		return "CLiente [UsuarioId=" + UsuarioId + ", PrimerNombre =" + PrimerNombre + ", Apellido=" + Apellido
				+ ", Pais=" + Pais + ", Documento=" + Documento + ", DocumentNro=" + DocumentNro + ", FechaNacimiento="
				+ Fechanacimiento + ", Edad=" + Edad + ", EstadoCivil=" + Estadocivil + ", ApellidoPaterno=" + ApellidoPaterno
				+ ", ApellidoMaterno=" + ApellidoMaterno + ", Email=" + Email + ", Phone=" + Telefono +  ", ReservacionId=" + reservacion + "]";
	}

     
}
