
package com.mycompany.administradorhotelero.Entidades.Entidades;

import java.util.logging.Logger;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
@Data
@Entity
@Table(name="Habitacion")
public class Habitacion {
  @Id
  
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="IdHabitacion")
	private int IdHabitacion;
	
	@Column(name="NumeroDeLaHabitacion")
	private String NumeroDeLaHabitacion;
	
	@Column(name="Tipo")
	private String Tipo;
	
	@Column(name="Precio")
	private double Precio;
	
	@Column(name="GastoTotal")
	private double GastoTotal;
	
	@Column(name="Balance")
	private String Balance;
	
	@Column(name="Adeuda")
	private double Adeuda;
	
	@Column(name="Divisa")
	private String Divisa;
	
	@Column(name="LimpiezaHabitacion")
	private String LimpiezaHabitacion;
	
	@Column(name="EstadoDeUso")
	private String EstadoDeUso;
	
	@Column(name="CantidadDePersonas")
	private int CantidadDePersonas;
	
	@Column(name="NombreDelcliente")
	private String NombreDelCliente;
	
        @ManyToOne(optional = true) // Indicamos que la relación es opcional
        @JoinColumn(name = "ReservacionId", referencedColumnName = "ReservacionId")
    private Reservacion reservacion;

    public Habitacion() {
    }

    public Habitacion(int IdHabitacion, String NumeroDeLaHabitacion, String Tipo, double Precio, double GastoTotal, String Balance, double Adeuda, String Divisa, String LimpiezaHabitacion, String EstadoDeUso, int CantidadDePersonas, String NombreDelCliente, Reservacion reservacion) {
        this.IdHabitacion = IdHabitacion;
        this.NumeroDeLaHabitacion = NumeroDeLaHabitacion;
        this.Tipo = Tipo;
        this.Precio = Precio;
        this.GastoTotal = GastoTotal;
        this.Balance = Balance;
        this.Adeuda = Adeuda;
        this.Divisa = Divisa;
        this.LimpiezaHabitacion = LimpiezaHabitacion;
        this.EstadoDeUso = EstadoDeUso;
        this.CantidadDePersonas = CantidadDePersonas;
        this.NombreDelCliente = NombreDelCliente;
        this.reservacion = reservacion;
    }

    public Habitacion(String NumeroDeLaHabitacion, String Tipo, double Precio,double GastoTotal, String Balance, double Adeuda, String Divisa, String LimpiezaHabitacion, String EstadoDeUso, int CantidadDePersonas, String NombreDelCliente, Reservacion reservacion) {
        this.NumeroDeLaHabitacion = NumeroDeLaHabitacion;
        this.Tipo = Tipo;
        this.Precio = Precio;
        this.GastoTotal = GastoTotal;
        this.Balance = Balance;
        this.Adeuda = Adeuda;
        this.Divisa = Divisa;
        this.LimpiezaHabitacion = LimpiezaHabitacion;
        this.EstadoDeUso = EstadoDeUso;
        this.CantidadDePersonas = CantidadDePersonas;
        this.NombreDelCliente = NombreDelCliente;
        this.reservacion = reservacion;
    }

    
    @Override
	public String toString() {
		return "Room [IdHabitacion=" + IdHabitacion + ", NumeroDeLaHabitacion=" + NumeroDeLaHabitacion + ", Tipo=" + Tipo + ", Precio=" + Precio
				+ ", GastoTotal=" + GastoTotal + ", Balance=" + Balance + ", Adeuda=" + Adeuda + 
				", Divisa=" + Divisa + ", LimpiezaHabitacion=" + LimpiezaHabitacion + ", EstadoDeUso=" + EstadoDeUso +
				", CantidadDePersonas=" + CantidadDePersonas + ", NombreDelCliente=" + NombreDelCliente + ", ReservacionId=" + reservacion + "]";
	}



    	
  
}
