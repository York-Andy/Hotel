
package com.mycompany.administradorhotelero.administradorhotelero;

import com.mycompany.administradorhotelero.Entidades.Entidades.Usuario;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

/**
 *
 * @author Lenovo
 */
public class UsuarioJpaController {
    private final EntityManagerFactory emf;

     public UsuarioJpaController(EntityManagerFactory emf) {
       this.emf=emf;
    }
     public EntityManager getEntityManager(){
    return emf.createEntityManager();
    
    }
    public UsuarioJpaController() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("entidadesJPAPU");
        this.emf=emf;
    }

    public void createUsuario(Usuario usuario) {
          EntityManager em =null;
     try{
     em = getEntityManager();
     em.getTransaction().begin();
     em.persist(usuario);
     em.getTransaction().commit();
     }finally{
     if(em!=null){
     em.close();
     }
    }

    }

    public void destroyCliente(int Id)throws Exception {
      EntityManager em = null;
        try{
        em = getEntityManager();
        em.getTransaction().begin();
        Usuario usuario;
        try{
        usuario=em.getReference(Usuario.class, Id);
        usuario.getId();
        }catch (EntityNotFoundException enfe){
            throw new Exception("el usuario con id "+Id+"no se encuentra habil o es inexistente ");
        }
        em.remove(usuario);
        em.getTransaction().commit();
        }finally{
        if(em!=null){
        em.close();
        }
        }  
    }

    public void editarUsuario(Usuario usuario)throws Exception {
        EntityManager em =null;
        try{
        em =getEntityManager();
        em.getTransaction().begin();
        usuario =em.merge(usuario);
        em.getTransaction().commit();
        }catch(Exception ex ){
        String msg =ex.getLocalizedMessage();
        if(msg == null ||msg.length()==0){
        int id =usuario.getId();
                  }
        
        }finally{
        if(em!=null){
        em.close();
        }
        } 
    }

    public Usuario traerUsuario(int Id) {
         EntityManager em = getEntityManager(); // Obtiene el EntityManager
    try {
        return em.find(Usuario.class, Id); // Utiliza el método find para buscar el usuario por su ID
    } catch (Exception ex) {
        // Manejar la excepción apropiadamente
        ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
        return null; // O devuelve un usuario nulo o lanza una excepción personalizada
    } finally {
        if (em != null && em.isOpen()) {
            em.close(); // Asegúrate de cerrar el EntityManager si está abierto
        }
    }

    }

    public List<Usuario> listarUsuario() {
        return findUsuario(true,-1,-1);
    }

    private List<Usuario> findUsuario(boolean all, int maximo, int minimo) {
        EntityManager em = getEntityManager(); // Obtener el EntityManager

        try {
            CriteriaQuery<Usuario> cq = (CriteriaQuery<Usuario>) em.getCriteriaBuilder().createQuery(Usuario.class);
            Root<Usuario> root = (Root<Usuario>) cq.from(Usuario.class);
            cq.select((Selection<? extends Usuario>) root);

            if (!all) {
                // Si no es necesario obtener todos los hoteles, aplica paginación
                Query q = em.createQuery(cq);
                q.setMaxResults(maximo);
                q.setFirstResult(minimo);
                return q.getResultList();
            } else {
                // Si se necesitan todos los hoteles
                return em.createQuery(cq).getResultList();
            }
        } catch (Exception ex) {
            // Manejar la excepción apropiadamente
            ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
            return null; // O devuelve una lista vacía o lanza una excepción personalizada
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Asegúrate de cerrar el EntityManager si está abierto
            }
        } 
    }

    public void destroyUsuario(int Id)throws Exception {
        EntityManager em = null;
        try{
        em = getEntityManager();
        em.getTransaction().begin();
        Usuario usuario;
        try{
        usuario=em.getReference(Usuario.class, Id);
        usuario.getId();
        }catch (EntityNotFoundException enfe){
            throw new Exception("el usuario con id "+Id+"no se encuentra habil o es inexistente ");
        }
        em.remove(usuario);
        em.getTransaction().commit();
        }finally{
        if(em!=null){
        em.close();
        }
        }   
    }

    
   
}
