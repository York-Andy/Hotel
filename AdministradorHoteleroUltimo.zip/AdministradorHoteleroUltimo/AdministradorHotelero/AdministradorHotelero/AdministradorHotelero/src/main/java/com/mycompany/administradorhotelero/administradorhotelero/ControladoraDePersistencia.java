package com.mycompany.administradorhotelero.administradorhotelero;


import com.mycompany.administradorhotelero.Entidades.Entidades.Cliente;
import com.mycompany.administradorhotelero.Entidades.Entidades.Agencia;
import com.mycompany.administradorhotelero.Entidades.Entidades.Habitacion;
import com.mycompany.administradorhotelero.Entidades.Entidades.Hotel;
import com.mycompany.administradorhotelero.Entidades.Entidades.Pago;
import com.mycompany.administradorhotelero.Entidades.Entidades.Reservacion;
import com.mycompany.administradorhotelero.Entidades.Entidades.StatusHotelero;
import com.mycompany.administradorhotelero.Entidades.Entidades.Usuario;
import com.mycompany.administradorhotelero.administradorhotelero.HotelJpaController;

import com.mycompany.administradorhotelero.administradorhotelero.UsuarioJpaController;
import com.mycompany.administradorhotelero.exceptions.NonexistentEntityException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
public class ControladoraDePersistencia {
   HotelJpaController hotelJpa = new HotelJpaController(); 
   StatusHoteleroJpaController StatusJpa =new StatusHoteleroJpaController();
   AgenciaJpaController AgenyJpa = new AgenciaJpaController ();
   ClienteJpaController clienteJpa = new ClienteJpaController();
   ReservacionJpaController reservacionJpa =new ReservacionJpaController();
   HabitacionJpaController HabitacionJpa =new HabitacionJpaController();
   UsuarioJpaController usuarioJpa = new UsuarioJpaController();
   PagoJpaController pagoJpa = new PagoJpaController();

    public void crearteH(Hotel hotel) {
     hotelJpa.createH(hotel);  
    }

    public void destroyH(int id) {
        try{
        hotelJpa.destroyH(id);
        }catch(Exception ex){
        Logger.getLogger(ControladoraDePersistencia.class.getName());
        }
    }

    public void editarH(Hotel hote) {
        try{
        hotelJpa.editarH(hote);
        }catch (Exception ex){
        Logger.getLogger(ControladoraDePersistencia.class.getName());
        }
    }

    public Hotel TraerHotel(int id) {
       return  hotelJpa.findHotel(id);
    }

    public List<Hotel> traerListahoteles() {
        return hotelJpa.findListaHoteles();
    }
   //-----------------------------------------------------------------
    //StatusHotelero
    //---------------------------------------------------------------
    public void createHS(StatusHotelero statushotelero) {
        StatusJpa.createHS(statushotelero);
    }

    public void destroyHS(int Id) {
       try {
           StatusJpa.destroyHS(Id);
       } catch (Exception ex) {
           Logger.getLogger(ControladoraDePersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }
    }

    public void editarHS(StatusHotelero statushotelero) {
        try{
        StatusJpa.editarHS(statushotelero);
        }catch (Exception ex){
        Logger.getLogger(ControladoraDePersistencia.class.getName());
        }
    }

    public StatusHotelero TraerStatusHotelero(long Id) {
        return StatusJpa.TraerStatusHotelero(Id);
    }
   public List<StatusHotelero> traerListaStatusH(){
     return StatusJpa.traerListaStatusH();
   }
   //-------------------------------------------------------
   //Agencia
   //-------------------------------------------------------

    public void createAgencia(Agencia agencia) {
     AgenyJpa.createAgencia(agencia);
    }

    public void destroyAgencia(long Id) {
       try {
           AgenyJpa.destroyAgencia(Id);
       } catch (Exception ex) {
           Logger.getLogger(ControladoraDePersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }
    }

    public void editarAgencia(Agencia agencia) {
       try{
        AgenyJpa.editarAgencia(agencia);
        }catch (Exception ex){
        Logger.getLogger(ControladoraDePersistencia.class.getName());
        }
  
    }
    public Agencia traerAgencia(long Id){
    return AgenyJpa.traerAgencia(Id);
    }

    List<Agencia> listarAgencia() {
        return AgenyJpa.listarAgencia();
    }
    //---------------------------------------------------
    //Cliente
    //---------------------------------------------------

    public void createCliente(Cliente cliente) {
        clienteJpa.createCliente(cliente);
    }

    public void destroyCliente(int UsuarioId) {
     try {
           clienteJpa.destroyCliente(UsuarioId);
       } catch (Exception ex) {
           Logger.getLogger(ControladoraDePersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }   
    }

    public void editarCliente(Cliente cliente) {
     try{
        clienteJpa.editarCliente(cliente);
        }catch (Exception ex){
        Logger.getLogger(ControladoraDePersistencia.class.getName());
        }   
    }

    public Cliente traerCliente(int UsuarioId) {
        return clienteJpa.traerCliente(UsuarioId);
    }

    public List<Cliente> listarCliente() {
        return clienteJpa.listarCliente();
    }
    //------------------------------------------------------
    //Pago
    //----------------------------------------------------

   public  void createPago(Pago pago) {
      pagoJpa.createPago(pago);  
    }

    public void destroyPago(int IdPago) {
      try {
           pagoJpa.destroyCliente(IdPago);
       } catch (Exception ex) {
           Logger.getLogger(ControladoraDePersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }     
    }

   public  void editarPago(Pago pago) {
       try{
        pagoJpa.editarPago(pago);
        }catch (Exception ex){
        Logger.getLogger(ControladoraDePersistencia.class.getName());
        }    
    }

    public Pago traerPago(int IdPago) {
        return pagoJpa.traerPago(IdPago);
    }

    public List<Pago> listarPago() {
        return pagoJpa.listarPago();
    }
    //------------------------------------------------------------
    //Habitacion
    //-----------------------------------------------------------
    public void createHabitacion(Habitacion habitacion) {
     HabitacionJpa.createHabitacion(habitacion);   
    }

    public void destroytHabitacion(int IdHabitacion) {
       try {
           HabitacionJpa.destroyHabitacion(IdHabitacion);
       } catch (Exception ex) {
           Logger.getLogger(ControladoraDePersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }
    }

    public void editarHabitacion(Habitacion habitacion) {
       try {
           HabitacionJpa.editarHabitacion(habitacion);
       } catch (Exception ex) {
           Logger.getLogger(ControladoraDePersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }
    }

    public Habitacion traerHabitacion(int IdHabitacion) {
       return  HabitacionJpa.traerHabitacion(IdHabitacion);
    }

   public  List<Habitacion> listarHabitacion() {
        return HabitacionJpa.listarHabitacion();
    }
    //----------------------------------------------------
   //Usuario
   //----------------------------------------------------
    public void createUsuario(Usuario usuario) {
        usuarioJpa.createUsuario(usuario);
    }

    public void destroytUsuario(int Id) {
         try {
           usuarioJpa.destroyCliente(Id);
       } catch (Exception ex) {
           Logger.getLogger(ControladoraDePersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }     
    }

    public void editarUsuario(Usuario usuario) {
       try {
           usuarioJpa.editarUsuario(usuario);
       } catch (Exception ex) {
           Logger.getLogger(ControladoraDePersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }
    }

    public Usuario traerUsuario(int Id) {
        return usuarioJpa.traerUsuario(Id);
    }

    public List<Usuario> listarUsuario() {
        return usuarioJpa.listarUsuario();
    }
  //------------------------------------------------------
    //Reservacion
    //-------------------------------------------------
   public  void createReservacion(Reservacion reservacion) {
        reservacionJpa.createReservacion(reservacion);
    }

    public void destroytReserva(int ReservacionId) {
       try {
           reservacionJpa.destroytReserva(ReservacionId);
       } catch (Exception ex) {
           Logger.getLogger(ControladoraDePersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }
    }

    public void editarReserva(Reservacion reserva) {
       try {
           reservacionJpa.editarReserva(reserva);
       } catch (Exception ex) {
           Logger.getLogger(ControladoraDePersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }
    }

    public Reservacion traerReservacion(int ReservacionId) {
       return  reservacionJpa.traerReservacion(ReservacionId);
    }

    public List<Reservacion> ListarReservacion() {
        return reservacionJpa.listarReservacion()  ;
    
    }

    
   
       

   
}
