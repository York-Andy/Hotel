
package com.mycompany.administradorhotelero.Entidades.Entidades;
import com.mycompany.administradorhotelero.Entidades.Entidades.Cliente;
import com.mycompany.administradorhotelero.Entidades.Entidades.Agencia;
import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;
@Entity
@Table(name="Reservacion")
@Data
public class Reservacion {
  
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ReservacionId")
    private int ReservacionId;

    @Column(name = "NombreGrupo")
    private String Nombregrupo;

    @Column(name = "FechaDeArribo")
    private String FechaDeArribo;

    @Column(name = "FechaDeSalida")
    private String FechaDeSalida;

    @Column(name = "TotalDias")
    private int TotalDias;

    @Column(name = "Empresa")
    private String empresa;

    @ManyToOne
    @JoinColumn(name = "usuario_id") // Debes especificar el nombre de la columna que representa la relación
    private Usuario usuario;

    @Column(name = "TipoDeCredito")
    private String TipoDeCredito;

    @Column(name = "EstadodeAgenda")
    private String EstadoDeAgenda;

    @Column(name = "Nota")
    private String Nota;

    @Column(name = "EstadoDePago")
    private boolean EstadoDepago;

    
    @Column(name = "NumeroDeLaHabitacion")
    private String NumeroDelaHabitacion;

    @Column(name = "HabitacionOcupada")
    private String Habitacionocupada;

    @Column(name = "CantidadDePersonas")
    private String CantidadDePersonas;

    @Column(name = "PrecioDeLasHabitaciones")
    private String PrecioDeLasHabitaciones;

    @Column(name = "PrecioSegunMonedaHabitacion")
    private String PrecioSegunMonedaHabitacion;

    @Column(name = "EstaChequeado")
    private String EstaChequeado;
     
    @ManyToOne
    @JoinColumn(name = "AgenciaNro", referencedColumnName = "AgenciaNro")
    private Agencia agencia;

    @Column(name = "ReferenciaNro")
    private String ReferenciaNro;
    
   @OneToMany(mappedBy = "reservacion", cascade = CascadeType.PERSIST)
   private List<Habitacion> habitaciones;

     
     @ManyToOne
    @JoinColumn(name = "hotel_id") // Nombre de la columna en la tabla Reservacion que hace referencia al Id del Hotel
     private Hotel hotel;

    public Reservacion() {
    }

    public Reservacion(int ReservacionId, String Nombregrupo, String FechaDeArribo, String FechaDeSalida, int TotalDias, String empresa, Usuario usuario, String TipoDeCredito, String EstadoDeAgenda, String Nota, boolean EstadoDepago, String NumeroDelaHabitacion, String Habitacionocupada, String CantidadDePersonas, String PrecioDeLasHabitaciones, String PrecioSegunMonedaHabitacion, String EstaChequeado, Agencia agencia, String ReferenciaNro, List<Habitacion> habitaciones, Hotel hotel) {
        this.ReservacionId = ReservacionId;
        this.Nombregrupo = Nombregrupo;
        this.FechaDeArribo = FechaDeArribo;
        this.FechaDeSalida = FechaDeSalida;
        this.TotalDias = TotalDias;
        this.empresa = empresa;
        this.usuario = usuario;
        this.TipoDeCredito = TipoDeCredito;
        this.EstadoDeAgenda = EstadoDeAgenda;
        this.Nota = Nota;
        this.EstadoDepago = EstadoDepago;
        this.NumeroDelaHabitacion = NumeroDelaHabitacion;
        this.Habitacionocupada = Habitacionocupada;
        this.CantidadDePersonas = CantidadDePersonas;
        this.PrecioDeLasHabitaciones = PrecioDeLasHabitaciones;
        this.PrecioSegunMonedaHabitacion = PrecioSegunMonedaHabitacion;
        this.EstaChequeado = EstaChequeado;
        this.agencia = agencia;
        this.ReferenciaNro = ReferenciaNro;
        this.habitaciones = habitaciones;
        this.hotel = hotel;
    }

    public Reservacion(String Nombregrupo, String FechaDeArribo, String FechaDeSalida, int TotalDias, String empresa, Usuario usuario, String TipoDeCredito, String EstadoDeAgenda, String Nota, boolean EstadoDepago, String NumeroDelaHabitacion, String Habitacionocupada, String CantidadDePersonas, String PrecioDeLasHabitaciones, String PrecioSegunMonedaHabitacion, String EstaChequeado, Agencia agencia, String ReferenciaNro, List<Habitacion> habitaciones, Hotel hotel) {
        this.Nombregrupo = Nombregrupo;
        this.FechaDeArribo = FechaDeArribo;
        this.FechaDeSalida = FechaDeSalida;
        this.TotalDias = TotalDias;
        this.empresa = empresa;
        this.usuario = usuario;
        this.TipoDeCredito = TipoDeCredito;
        this.EstadoDeAgenda = EstadoDeAgenda;
        this.Nota = Nota;
        this.EstadoDepago = EstadoDepago;
        this.NumeroDelaHabitacion = NumeroDelaHabitacion;
        this.Habitacionocupada = Habitacionocupada;
        this.CantidadDePersonas = CantidadDePersonas;
        this.PrecioDeLasHabitaciones = PrecioDeLasHabitaciones;
        this.PrecioSegunMonedaHabitacion = PrecioSegunMonedaHabitacion;
        this.EstaChequeado = EstaChequeado;
        this.agencia = agencia;
        this.ReferenciaNro = ReferenciaNro;
        this.habitaciones = habitaciones;
        this.hotel = hotel;
    }

 @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + (int) (this.ReservacionId ^ (this.ReservacionId >>> 32));
        hash = 23 * hash + Objects.hashCode(this.Nombregrupo);
        hash = 23 * hash + Objects.hashCode(this.FechaDeArribo);
        hash = 23 * hash + Objects.hashCode(this.FechaDeSalida);
        hash = 23 * hash + this.TotalDias;
        hash = 23 * hash + Objects.hashCode(this.empresa);
        hash = 23 * hash + Objects.hashCode(this.usuario);
        hash = 23 * hash + Objects.hashCode(this.TipoDeCredito);
        hash = 23 * hash + Objects.hashCode(this.EstadoDeAgenda);
        hash = 23 * hash + Objects.hashCode(this.Nota);
        hash = 23 * hash + (this.EstadoDepago ? 1 : 0);
        hash = 23 * hash + Objects.hashCode(this.NumeroDelaHabitacion);
        hash = 23 * hash + Objects.hashCode(this.Habitacionocupada);
        hash = 23 * hash + Objects.hashCode(this.CantidadDePersonas);
        hash = 23 * hash + Objects.hashCode(this.PrecioDeLasHabitaciones);
        hash = 23 * hash + Objects.hashCode(this.PrecioSegunMonedaHabitacion);
        hash = 23 * hash + Objects.hashCode(this.EstaChequeado);
        hash = 23 * hash + Objects.hashCode(this.agencia);
        hash = 23 * hash + Objects.hashCode(this.ReferenciaNro);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Reservacion other = (Reservacion) obj;
        if (this.ReservacionId != other.ReservacionId) {
            return false;
        }
        if (this.TotalDias != other.TotalDias) {
            return false;
        }
        if (this.EstadoDepago != other.EstadoDepago) {
            return false;
        }
        if (!Objects.equals(this.Nombregrupo, other.Nombregrupo)) {
            return false;
        }
        if (!Objects.equals(this.FechaDeArribo, other.FechaDeArribo)) {
            return false;
        }
        if (!Objects.equals(this.FechaDeSalida, other.FechaDeSalida)) {
            return false;
        }
        if (!Objects.equals(this.empresa, other.empresa)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.TipoDeCredito, other.TipoDeCredito)) {
            return false;
        }
        if (!Objects.equals(this.EstadoDeAgenda, other.EstadoDeAgenda)) {
            return false;
        }
        if (!Objects.equals(this.Nota, other.Nota)) {
            return false;
        }
        if (!Objects.equals(this.NumeroDelaHabitacion, other.NumeroDelaHabitacion)) {
            return false;
        }
        if (!Objects.equals(this.Habitacionocupada, other.Habitacionocupada)) {
            return false;
        }
        if (!Objects.equals(this.CantidadDePersonas, other.CantidadDePersonas)) {
            return false;
        }
        if (!Objects.equals(this.PrecioDeLasHabitaciones, other.PrecioDeLasHabitaciones)) {
            return false;
        }
        if (!Objects.equals(this.PrecioSegunMonedaHabitacion, other.PrecioSegunMonedaHabitacion)) {
            return false;
        }
        if (!Objects.equals(this.EstaChequeado, other.EstaChequeado)) {
            return false;
        }
        if (!Objects.equals(this.agencia, other.agencia)) {
            return false;
        }
        if (!Objects.equals(this.ReferenciaNro, other.ReferenciaNro)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Reservacion{" + "ReservacionId=" + ReservacionId + ", NombreGrupo=" + Nombregrupo + ", FechaDeArribo=" + FechaDeArribo + ", FechaDeSalida=" + FechaDeSalida + ", TotalDias=" + TotalDias + ", Agencia=" + agencia + ", UsuarioId=" + usuario+ ", TipoDeCredito=" + TipoDeCredito + ", EstadoAgenda=" + EstadoDeAgenda + ", Nota=" + Nota + ", EstadoPago=" + EstadoDepago + ", Numerohabitacion=" + NumeroDelaHabitacion + ", HabitacionOcupada=" + Habitacionocupada + ", CantidadDePersonas=" + CantidadDePersonas + ", PrecioDeLasHabitaciones=" + PrecioDeLasHabitaciones + ", PrecioSegunMonedaHabitacion=" + PrecioSegunMonedaHabitacion + ", EstaChequeado=" + EstaChequeado + ", Empresa=" + empresa + ", ReferenciaNro=" + ReferenciaNro + '}';
    }


}
