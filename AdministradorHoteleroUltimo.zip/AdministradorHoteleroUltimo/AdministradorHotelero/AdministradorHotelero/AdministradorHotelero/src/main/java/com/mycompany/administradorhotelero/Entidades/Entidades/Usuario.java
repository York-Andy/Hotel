
package com.mycompany.administradorhotelero.Entidades.Entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
@Data
@Entity
@Table(name="Usuario")
public class Usuario {
   @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id")
	private Integer Id;
	
	@Column(name="Nombre")
	private String Nombre;
	
	@Column(name="Apellido")
	private String Apellido;
	
	@Column(name="NombreDeUsuario")
	private String NombreDeUsuario;
	
	@Column(name="Password")
	private String Password;
	
	@Column(name="Email")
	private String Email;
	
	@Column(name="RolEnHotel")
	private String RolEnHotel;
         // Relación con Hotel
    @ManyToOne
    @JoinColumn(name = "hotel_id")
    private Hotel hotel;

    public Usuario() {
    }

    public Usuario(Integer Id, String Nombre, String Apellido, String NombreDeUsuario, String Password, String Email, String RolEnHotel, Hotel hotel) {
        this.Id = Id;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.NombreDeUsuario = NombreDeUsuario;
        this.Password = Password;
        this.Email = Email;
        this.RolEnHotel = RolEnHotel;
        this.hotel = hotel;
    }

    public Usuario(String Nombre, String Apellido, String NombreDeUsuario, String Password, String Email, String RolEnHotel, Hotel hotel) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.NombreDeUsuario = NombreDeUsuario;
        this.Password = Password;
        this.Email = Email;
        this.RolEnHotel = RolEnHotel;
        this.hotel = hotel;
    }
  
    

    
   @Override
	public String toString() {
		return "Usuario [Id=" + Id + ", Nombre=" + Nombre + ", Apellido=" + Apellido + ", NombreDeUsuario=" + NombreDeUsuario
				+ ", Password=" + Password + ", Email=" + Email + ", RolEnHotel=" + RolEnHotel + "]";
	}

    

	
 
}
