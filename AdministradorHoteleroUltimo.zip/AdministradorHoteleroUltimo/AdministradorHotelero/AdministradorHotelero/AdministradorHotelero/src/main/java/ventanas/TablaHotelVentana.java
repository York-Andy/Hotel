/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ventanas;

import com.lowagie.text.Image;
import com.mycompany.administradorhotelero.Entidades.Entidades.Hotel;
import com.mycompany.administradorhotelero.administradorhotelero.HotelJpaController;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lenovo
 */
public class TablaHotelVentana extends javax.swing.JFrame {
     private DefaultTableModel modelo;
     private Image imagenfondo;
     private HotelJpaController hotelJpa;
     private List<Hotel>hotel;
    public TablaHotelVentana() {
        initComponents();
       modelo = new DefaultTableModel();
        hotelJpa = new HotelJpaController();
        hotel = hotelJpa.findListaHoteles(); // Aquí se inicializa la lista de hoteles

        if (hotel != null && !hotel.isEmpty()) { // Verificar si la lista de hoteles no está vacía
            armarCabecera();
            cargarHotel();
        } else {
            // Manejar el caso en el que la lista de hoteles está vacía o es nula
            System.out.println("La lista de hoteles está vacía o no inicializada.");
        }
    }

    

    public void armarCabecera() {
    ArrayList<Object> filaCabecera = new ArrayList<>();
    filaCabecera.add("Id");
    filaCabecera.add("Nombre");
    filaCabecera.add("Cuantas Estrellas");
    filaCabecera.add("Fotos");
    filaCabecera.add("Dueño");
    filaCabecera.add("Número Telefónico");
    filaCabecera.add("País");
    filaCabecera.add("Género");
    filaCabecera.add("Capacidad de la Habitación");
    filaCabecera.add("Ciudad");
    filaCabecera.add("Descripción de la Habitación");
    filaCabecera.add("Dirección");
    // Agregar más columnas según sea necesario
    for (Object it : filaCabecera) {
        modelo.addColumn(it);
    }
    jtHotel.setModel(modelo);
}
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtHotel = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setFocusCycleRoot(false);

        jPanel1.setBackground(new java.awt.Color(102, 0, 255));
        jPanel1.setBorder(new javax.swing.border.MatteBorder(null));

        jtHotel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jtHotel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jtHotel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtHotelMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtHotel);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Fotos/Imagen/hotel2.jpg"))); // NOI18N
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 2, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("HOTEL");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(114, 114, 114)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 763, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(jLabel2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(115, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jtHotelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtHotelMouseClicked
       int filaSeleccionada = jtHotel.getSelectedRow();
    Object idHotelObj = jtHotel.getValueAt(filaSeleccionada, 0);

    System.out.println("Tipo de dato del ID del hotel: " + idHotelObj.getClass().getName()); // Agregar esta línea para imprimir el tipo de dato

    if (idHotelObj instanceof Integer) {
        Integer idHotel = (Integer) idHotelObj;

        String nombre = (String) jtHotel.getValueAt(filaSeleccionada, 1);
        Integer estrellasInt = (Integer) jtHotel.getValueAt(filaSeleccionada, 2);
        String estrellas = estrellasInt.toString();
        String fotos = (String) jtHotel.getValueAt(filaSeleccionada, 3);
        String dueño = (String) jtHotel.getValueAt(filaSeleccionada, 4);
        String numeroTelefonico = (String) jtHotel.getValueAt(filaSeleccionada, 5);
        String pais = (String) jtHotel.getValueAt(filaSeleccionada, 6);
        String genero = (String) jtHotel.getValueAt(filaSeleccionada, 7);
        String capacidadHabi = jtHotel.getValueAt(filaSeleccionada, 8).toString();
        String cuidad = (String) jtHotel.getValueAt(filaSeleccionada, 9);
        String descripcion = (String) jtHotel.getValueAt(filaSeleccionada, 10);
        String direccion = (String) jtHotel.getValueAt(filaSeleccionada, 11);

        // Llenar campos de texto de la ventana HotelX
        HotelX hotelEditorFrame = new HotelX();
        hotelEditorFrame.setDatos(idHotel, nombre, estrellas, fotos, dueño, numeroTelefonico, pais, genero, capacidadHabi, cuidad, descripcion, direccion);
        hotelEditorFrame.setVisible(true);
    } else {
        System.err.println("El ID del hotel no es del tipo esperado.");
    }           
    }//GEN-LAST:event_jtHotelMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TablaHotelVentana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TablaHotelVentana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TablaHotelVentana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TablaHotelVentana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TablaHotelVentana().setVisible(true);
            }
        });
    }
   public void cargarHotel() {
    DefaultTableModel modelo = (DefaultTableModel) jtHotel.getModel();
    modelo.setRowCount(0); // Limpiar la tabla antes de cargar nuevos datos

    if (hotel != null && !hotel.isEmpty()) { // Verificar si la lista hotel está inicializada y no está vacía
        for (Hotel h : hotel) {
            Object[] fila = new Object[]{
                h.getId(),
                h.getNombre(),
                h.getCuantasEstrellas(),
                h.getFotos(),
                h.getDueño(),
                h.getNumerotelefonico(),
                h.getPais(),
                h.getGenero(),
                h.getCapacidadDeLaHabitacion(),
                h.getCuidad(),
                h.getDescripcionDelaHabitacion(),
                h.getDireccion()
            };
            modelo.addRow(fila);
        }
    } else {
        System.out.println("La lista de hoteles está vacía o no inicializada.");
    }

    jtHotel.setModel(modelo);
}


    // Otros métodos de la clase

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jtHotel;
    // End of variables declaration//GEN-END:variables
}
