
package com.mycompany.administradorhotelero.Entidades.Entidades;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
@Entity
@Table(name="StatusHotelero")
@Data
public class StatusHotelero {
 @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id")
	private long Id;
	
	@Column(name="FechaYhora")
	private LocalDate FechaYhora;
	
	@Column(name="Calificado")
	private Boolean Calificado;
        // Relación con Hotel
    @ManyToOne
    @JoinColumn(name = "hotel_id")
     private Hotel hotel;

    public StatusHotelero(long Id, LocalDate FechaYhora, Boolean Calificado, Hotel hotel) {
        this.Id = Id;
        this.FechaYhora = FechaYhora;
        this.Calificado = Calificado;
        this.hotel = hotel;
    }

    public StatusHotelero(LocalDate FechaYhora, Boolean Calificado, Hotel hotel) {
        this.FechaYhora = FechaYhora;
        this.Calificado = Calificado;
        this.hotel = hotel;
    }
   
   

    public StatusHotelero() {
    }

   
	
 @Override
   public String toString(){
   
     	return "StatusHotelero [Id=" + Id + ", FechaYhora=" + FechaYhora + ", Calificado=" + Calificado + "]";
   
   }
}
