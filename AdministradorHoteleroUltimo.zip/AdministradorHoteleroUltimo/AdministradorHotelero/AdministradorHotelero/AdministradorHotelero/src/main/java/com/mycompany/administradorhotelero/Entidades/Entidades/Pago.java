
package com.mycompany.administradorhotelero.Entidades.Entidades;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Data
@Entity
@Table(name="Pago")
public class Pago implements Serializable {
   @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="IdPago")
    private int idPago;
    
    @Column(name="Titulo")
    private String Titulo;
    
    @Column(name="TipoDePago")
    private String TipoDePago;
    
    @Column(name="Precio")
    private String Precio;
    
    //@ManyToOne
    //@JoinColumn(name = "Divisa_id", referencedColumnName = "id")
    private Divisa divisa;
    
    @Column(name="Descripcion")
    private String Descripcion;
    
    @Column(name="HabitacionNro")
    private String HabitacionNro;
    
    @Column(name="FechaYHora")
    private String FechaYhora;

    public Pago() {
    }

    public Pago(int idPago, String Titulo, String TipoDePago, String Precio, Divisa divisa, String Descripcion, String HabitacionNro, String FechaYhora) {
        this.idPago = idPago;
        this.Titulo = Titulo;
        this.TipoDePago = TipoDePago;
        this.Precio = Precio;
        this.divisa = divisa;
        this.Descripcion = Descripcion;
        this.HabitacionNro = HabitacionNro;
        this.FechaYhora = FechaYhora;
    }

    public Pago(String Titulo, String TipoDePago, String Precio, Divisa divisa, String Descripcion, String HabitacionNro, String FechaYhora) {
        this.Titulo = Titulo;
        this.TipoDePago = TipoDePago;
        this.Precio = Precio;
        this.divisa = divisa;
        this.Descripcion = Descripcion;
        this.HabitacionNro = HabitacionNro;
        this.FechaYhora = FechaYhora;
    }

    
        @Override
	public String toString() {
		return "Pago [idPago="+ idPago +", Titulo=" + Titulo + ", TipoDePago=" + TipoDePago + ", Precio=" + Precio + ", Divisa="
				+ divisa + ", Descripcion=" + Descripcion + ", HabitacionNro=" + HabitacionNro + ", FechaYhora=" + FechaYhora + "]";
	}
	
  
}
