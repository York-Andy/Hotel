
package com.mycompany.administradorhotelero.administradorhotelero;

import com.mycompany.administradorhotelero.Entidades.Entidades.Pago;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;


public class PagoJpaController implements Serializable {
    private final EntityManagerFactory emf;
     public PagoJpaController(EntityManagerFactory emf) {
       this.emf=emf;
    }

    public PagoJpaController() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("entidadesJPAPU");
        this.emf = emf;
    } 
     public EntityManager getEntityManager(){
    return emf.createEntityManager();
    
    }


   public  void createPago(Pago pago) {
         EntityManager em =null;
     try{
     em = getEntityManager();
     em.getTransaction().begin();
     em.persist(pago);
     em.getTransaction().commit();
     }finally{
     if(em!=null){
     em.close();
     }
    }
    }

    public void destroyCliente(int IdPago)throws Exception  {
        EntityManager em = null;
        try{
        em = getEntityManager();
        em.getTransaction().begin();
        Pago pago;
        try{
        pago=em.getReference(Pago.class, IdPago);
        pago.getIdPago();
        }catch (EntityNotFoundException enfe){
            throw new Exception("el pago con  id "+IdPago+"no se encuentra habil o es inexistente ");
        }
        em.remove(pago);
        em.getTransaction().commit();
        }finally{
        if(em!=null){
        em.close();
        }
        } 
    }

    public void editarPago(Pago pago)throws Exception {
        EntityManager em =null;
        try{
        em =getEntityManager();
        em.getTransaction().begin();
        pago =em.merge(pago);
        em.getTransaction().commit();
        }catch(Exception ex ){
        String msg =ex.getLocalizedMessage();
        if(msg == null ||msg.length()==0){
        int IdPago =pago.getIdPago();
                  }
        
        }finally{
        if(em!=null){
        em.close();
        }
        }
    }

    public Pago traerPago(int IdPago) {
       EntityManager em = getEntityManager(); // Obtiene el EntityManager
    try {
        return em.find(Pago.class, IdPago); // Utiliza el método find para buscar el pago por su ID
    } catch (Exception ex) {
        // Manejar la excepción apropiadamente
        ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
        return null; // O devuelve un hotel nulo o lanza una excepción personalizada
    } finally {
        if (em != null && em.isOpen()) {
            em.close(); // Asegúrate de cerrar el EntityManager si está abierto
        }
    } 
    }

    public List<Pago> listarPago() {
        return listarPago(true,-1,-1);
    }

    private List<Pago> listarPago(boolean all, int maximo, int minimo) {
        EntityManager em = getEntityManager(); // Obtener el EntityManager

        try {
            CriteriaQuery<Pago> cq = (CriteriaQuery<Pago>) em.getCriteriaBuilder().createQuery(Pago.class);
            Root<Pago> root = (Root<Pago>) cq.from(Pago.class);
            cq.select((Selection<? extends Pago>) root);

            if (!all) {
                // Si no es necesario obtener todos los hoteles, aplica paginación
                Query q = em.createQuery(cq);
                q.setMaxResults(maximo);
                q.setFirstResult(minimo);
                return q.getResultList();
            } else {
                // Si se necesitan todos los hoteles
                return em.createQuery(cq).getResultList();
            }
        } catch (Exception ex) {
            // Manejar la excepción apropiadamente
            ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
            return null; // O devuelve una lista vacía o lanza una excepción personalizada
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Asegúrate de cerrar el EntityManager si está abierto
            }
        }

           }
}
