/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ventanas;

import com.mycompany.administradorhotelero.Entidades.Entidades.Habitacion;
import com.mycompany.administradorhotelero.Entidades.Entidades.Reservacion;
import com.mycompany.administradorhotelero.administradorhotelero.HabitacionJpaController;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lenovo
 */
public class HabitacionesJFrame extends ResponsiveJFrame {

    private JTable table;
    private DefaultTableModel tableModel;
    public HabitacionesJFrame() {
       
    super();
    initComponents();
    setTitle("Gestión de Habitaciones");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    setLocationRelativeTo(null); // Centrar la ventana en la pantalla
    initTipoComboBox();// Llamada al método para inicializar el JComboBox jbTipo
    createDivisaComboBox();
    setVisible(true);
    
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jtIdHabi = new javax.swing.JTextField();
        jtNroHabi = new javax.swing.JTextField();
        jbTipo = new javax.swing.JComboBox<>();
        jtPrecio = new javax.swing.JTextField();
        jtGastoTotal = new javax.swing.JTextField();
        jtBalance = new javax.swing.JTextField();
        jtDeuda = new javax.swing.JTextField();
        jcLimpieza = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtEstado = new javax.swing.JTextArea();
        jtCantidadP = new javax.swing.JTextField();
        jtCliente = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jComboBox = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 153));

        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("GESTION DE HABITACIONES");

        jLabel2.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel2.setText("ID HABITACION:");

        jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel3.setText("NRO HABITACION:");

        jLabel4.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel4.setText("TIPO:");

        jLabel5.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel5.setText("PRECIO:");

        jLabel6.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel6.setText("GASTO TOTAL:");

        jLabel7.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel7.setText("BALANCE:");

        jLabel8.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel8.setText("ADEUDA:");

        jLabel9.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 12)); // NOI18N
        jLabel9.setText("LIMPIEZA HABITACION:");

        jLabel10.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 12)); // NOI18N
        jLabel10.setText("ESTADO DE USO:");

        jLabel11.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel11.setText("CANTIDAD DE PERSONAS:");

        jLabel12.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel12.setText("NOMBRE CLIENTE:");

        jtIdHabi.setBackground(new java.awt.Color(102, 102, 102));
        jtIdHabi.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jtIdHabi.setForeground(new java.awt.Color(102, 102, 102));
        jtIdHabi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jtNroHabi.setBackground(new java.awt.Color(102, 102, 102));
        jtNroHabi.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 12)); // NOI18N
        jtNroHabi.setForeground(new java.awt.Color(255, 255, 255));
        jtNroHabi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jbTipo.setBackground(new java.awt.Color(102, 102, 102));
        jbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jbTipo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jbTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbTipoActionPerformed(evt);
            }
        });

        jtPrecio.setBackground(new java.awt.Color(102, 102, 102));
        jtPrecio.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jtPrecio.setForeground(new java.awt.Color(255, 255, 255));
        jtPrecio.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jtGastoTotal.setBackground(new java.awt.Color(102, 102, 102));
        jtGastoTotal.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jtGastoTotal.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jtBalance.setBackground(new java.awt.Color(102, 102, 102));
        jtBalance.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 12)); // NOI18N
        jtBalance.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jtDeuda.setBackground(new java.awt.Color(102, 102, 102));
        jtDeuda.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 12)); // NOI18N
        jtDeuda.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jcLimpieza.setBackground(new java.awt.Color(102, 102, 102));
        jcLimpieza.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jcLimpieza.setText("MARCAR SI ESTA LIMPIA");
        jcLimpieza.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jtEstado.setBackground(new java.awt.Color(102, 102, 102));
        jtEstado.setColumns(20);
        jtEstado.setRows(5);
        jScrollPane1.setViewportView(jtEstado);

        jtCantidadP.setBackground(new java.awt.Color(102, 102, 102));
        jtCantidadP.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jtCantidadP.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jtCliente.setBackground(new java.awt.Color(102, 102, 102));
        jtCliente.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 12)); // NOI18N
        jtCliente.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Fotos/Imagen/hotel3.jpg"))); // NOI18N
        jLabel13.setText("jLabel13");
        jLabel13.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton1.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jButton1.setText("CREAR HABITACION");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jButton2.setText("DESABILITAR HABITACION");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton3.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 12)); // NOI18N
        jButton3.setText("LISTAR HABITACIONES");
        jButton3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton4.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jButton4.setText("EDITAR HABITACION");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel14.setBackground(new java.awt.Color(102, 102, 102));
        jLabel14.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jLabel14.setText("DIVIDA:");

        jComboBox.setBackground(new java.awt.Color(102, 102, 102));
        jComboBox.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 12)); // NOI18N
        jComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel11))))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jtIdHabi, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(jbTipo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jtPrecio)
                                                    .addComponent(jtNroHabi)
                                                    .addComponent(jScrollPane1)
                                                    .addComponent(jtBalance)
                                                    .addComponent(jtDeuda)
                                                    .addComponent(jtGastoTotal))
                                                .addGap(60, 60, 60))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(jcLimpieza)
                                                    .addComponent(jComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(61, 61, 61)))))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButton1)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING)))
                                .addGap(78, 78, 78))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jtCantidadP, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jtCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton4)
                        .addGap(97, 97, 97))))
            .addGroup(layout.createSequentialGroup()
                .addGap(188, 188, 188)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(72, 72, 72)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jtIdHabi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtNroHabi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(52, 52, 52)
                                .addComponent(jLabel10))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtBalance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(jButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jtGastoTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jtDeuda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jButton3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(jtCantidadP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(jComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jcLimpieza))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jtCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4)
                            .addComponent(jLabel12))))
                .addGap(0, 27, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbTipoActionPerformed
       
    }//GEN-LAST:event_jbTipoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
   // Obtener los detalles de la habitación ingresados por el usuario desde la interfaz de usuario
try {
    String nombreCliente = jtCliente.getText();
    String numeroHabitacionStr = jtNroHabi.getText();
    String tipo = jbTipo.getSelectedItem().toString();
    String precioStr = jtPrecio.getText();
    String cantidadDePersonasStr = jtCantidadP.getText();
    String estadoDeUso = jtEstado.getText();
    String gastoTotalStr = jtGastoTotal.getText();
    String limpiezaHabitacion = String.valueOf(jcLimpieza.isSelected());
    String adeudaStr = jtDeuda.getText();
    String balance = jtBalance.getText();
    
    // Obtener la divisa seleccionada del JComboBox
    String divisa = jComboBox.getSelectedItem().toString(); 

    // Verificar si alguno de los campos está vacío
    if (nombreCliente.isEmpty() || numeroHabitacionStr.isEmpty() || tipo.isEmpty() || precioStr.isEmpty() || cantidadDePersonasStr.isEmpty() || gastoTotalStr.isEmpty() || adeudaStr.isEmpty() || balance.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Error: Debes completar todos los campos.");
        return; // Salir del método si hay campos vacíos
    }

    // Convertir los valores numéricos
    int numeroHabitacion = Integer.parseInt(numeroHabitacionStr);
    double precio = Double.parseDouble(precioStr);
    int cantidadDePersonas = Integer.parseInt(cantidadDePersonasStr);
    double gastoTotal = Double.parseDouble(gastoTotalStr);
    double adeuda = Double.parseDouble(adeudaStr);

    // Crear una nueva instancia de Habitacion con los detalles obtenidos
    Habitacion habitacion = new Habitacion();
    habitacion.setNombreDelCliente(nombreCliente);
    habitacion.setNumeroDeLaHabitacion(String.valueOf(numeroHabitacion));
    habitacion.setTipo(tipo);
    habitacion.setPrecio(precio);
    habitacion.setCantidadDePersonas(cantidadDePersonas);
    habitacion.setEstadoDeUso(estadoDeUso);
    habitacion.setGastoTotal(gastoTotal);
    habitacion.setLimpiezaHabitacion(limpiezaHabitacion);
    habitacion.setAdeuda(adeuda);
    habitacion.setBalance(balance);
    habitacion.setDivisa(divisa); // Agregar la divisa a la habitación

    // Obtener una instancia de Reservacion
    Reservacion reservacion = createReservacion(); 
    habitacion.setReservacion(reservacion);

    EntityManager em = null; 

    try {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("entidadesJPAPU");
        HabitacionJpaController habitacionController = new HabitacionJpaController(emf);
        em = emf.createEntityManager();
        em.getTransaction().begin();
        habitacionController.createHabitacion(habitacion);
        em.getTransaction().commit();
        JOptionPane.showMessageDialog(null, "Habitación habilitada exitosamente");
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Error: Debes ingresar valores numéricos válidos para los campos numéricos.");
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Error al habilitar la habitación: " + ex.getMessage());
    } finally {
        if (em != null && em.isOpen()) 
            em.close();
    }
} catch (NumberFormatException ex) {
    JOptionPane.showMessageDialog(null, "Error: Debes ingresar valores numéricos válidos para los campos numéricos.");




}



// Limpiar los campos de texto de la ventana
jtIdHabi.setText("");
jtNroHabi.setText("");
jbTipo.setSelectedIndex(0);
jtPrecio.setText("");
jtGastoTotal.setText("");
jtEstado.setText("");
jtBalance.setText("");
jtDeuda.setText("");
jtCantidadP.setText("");
jtCliente.setText("");
jcLimpieza.setSelected(false);

    }//GEN-LAST:event_jButton1ActionPerformed
private void initTipoComboBox() {
    // Define una lista de descripciones de habitaciones
    String[] descripciones = {
        "Individual",
        "Doble",
        "Triple",
        "Suite",
        "Familiar",
        "VIP",
        "Mixto",
        "Ejecutiva",
        "Presidencial"
    };

    // Crea un modelo de ComboBox con la lista de descripciones de habitaciones
    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(descripciones);

    // Asigna el modelo al JComboBox
    jbTipo.setModel(model);

    // Imprime el contenido del modelo del JComboBox
    System.out.println("Modelo de datos del JComboBox:");
    for (int i = 0; i < jbTipo.getModel().getSize(); i++) {
        System.out.println(jbTipo.getModel().getElementAt(i));
    }
}

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HabitacionesJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HabitacionesJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HabitacionesJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HabitacionesJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HabitacionesJFrame().setVisible(true);
            }
        });
    }
    // Método para crear una instancia de Reservacion
private Reservacion createReservacion() {
    // Aquí debes implementar la lógica para crear y devolver una instancia de Reservacion
    Reservacion reservacion = new Reservacion();
    // Configurar la reservación según tus necesidades
    return reservacion;
}
// Método para crear y retornar el JComboBox de divisa
    private void createDivisaComboBox() {
      // Array con las opciones de divisa
    String[] opcionesDivisa = {"USD", "EUR", "GBP", "JPY", "CAD"};

    // Crea un modelo de ComboBox con las opciones de divisa
    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(opcionesDivisa);

    // Asigna el modelo al JComboBox de divisa
    jComboBox.setModel(model);

    // Imprime el contenido del modelo del JComboBox de divisa
    System.out.println("Modelo de datos del JComboBox de divisa:");
    for (int i = 0; i < jComboBox.getModel().getSize(); i++) {
        System.out.println(jComboBox.getModel().getElementAt(i));
    
    }
    }
    

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> jbTipo;
    private javax.swing.JCheckBox jcLimpieza;
    private javax.swing.JTextField jtBalance;
    private javax.swing.JTextField jtCantidadP;
    private javax.swing.JTextField jtCliente;
    private javax.swing.JTextField jtDeuda;
    private javax.swing.JTextArea jtEstado;
    private javax.swing.JTextField jtGastoTotal;
    private javax.swing.JTextField jtIdHabi;
    private javax.swing.JTextField jtNroHabi;
    private javax.swing.JTextField jtPrecio;
    // End of variables declaration//GEN-END:variables

    
}
