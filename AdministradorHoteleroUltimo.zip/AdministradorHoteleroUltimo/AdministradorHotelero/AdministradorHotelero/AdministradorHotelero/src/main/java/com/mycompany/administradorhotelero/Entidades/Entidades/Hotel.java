
package com.mycompany.administradorhotelero.Entidades.Entidades;
import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name="Hotel")
@Data

public class Hotel implements Serializable{
  @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id")
	private int Id;
	
    @Column(name="Nombre")
	private String Nombre;
	
    @Column(name="CuantasEstrellas")
	private int CuantasEstrellas;
    
    @Column(name="Fotos")
    private String Fotos;
    
	@Column(name="Dueño")
	private String Dueño;	
	
	@Column(name="NumeroTelefonico")
	private String Numerotelefonico;
	
	@Column(name="Pais")
    private String Pais;
	
	@Column(name="Genero")
    private String Genero;
	
	@Column(name="CapacidadDeLahabitacion")
	private int CapacidadDeLaHabitacion;
	
	@Column(name="Ciudad")
    private String Cuidad;
	
	@Column(name="DescripcionDeLaHabitacion")
	private String DescripcionDelaHabitacion;

	@Column(name="Direccion")
	private String Direccion;
        @OneToMany(mappedBy = "hotel") // "hotel" es la propiedad en la clase Reservacion que representa la relación ManyToOne con Hotel
    private List<Reservacion> reservaciones;
	public Hotel() {
		
	}

    public Hotel(int  Id, String Nombre, int CuantasEstrellas, String Fotos, String Dueño, String Numerotelefonico, String Pais, String Genero, int CapacidadDeLaHabitacion, String Cuidad, String DescripcionDelaHabitacion, String Direccion, List<Reservacion> reservaciones) {
        this.Id = Id;
        this.Nombre = Nombre;
        this.CuantasEstrellas = CuantasEstrellas;
        this.Fotos = Fotos;
        this.Dueño = Dueño;
        this.Numerotelefonico = Numerotelefonico;
        this.Pais = Pais;
        this.Genero = Genero;
        this.CapacidadDeLaHabitacion = CapacidadDeLaHabitacion;
        this.Cuidad = Cuidad;
        this.DescripcionDelaHabitacion = DescripcionDelaHabitacion;
        this.Direccion = Direccion;
        this.reservaciones = reservaciones;
    }

    public Hotel(String Nombre, int CuantasEstrellas, String Fotos, String Dueño, String Numerotelefonico, String Pais, String Genero, int CapacidadDeLaHabitacion, String Cuidad, String DescripcionDelaHabitacion, String Direccion, List<Reservacion> reservaciones) {
        this.Nombre = Nombre;
        this.CuantasEstrellas = CuantasEstrellas;
        this.Fotos = Fotos;
        this.Dueño = Dueño;
        this.Numerotelefonico = Numerotelefonico;
        this.Pais = Pais;
        this.Genero = Genero;
        this.CapacidadDeLaHabitacion = CapacidadDeLaHabitacion;
        this.Cuidad = Cuidad;
        this.DescripcionDelaHabitacion = DescripcionDelaHabitacion;
        this.Direccion = Direccion;
        this.reservaciones = reservaciones;
    }

    
  @Override
 public String toString (){
      return "Hotel [Id=" + Id + ", Nombre=" + Nombre+ ", CuantasEstrellas=" + CuantasEstrellas + ", picture=" + Fotos+ ", Dueño="
				+ Dueño + ", NumeroTelefonico=" + Numerotelefonico+ ", country=" + Pais + ", Genero=" + Genero+ ", CapacidadDeLaHabitacion="
				+ CapacidadDeLaHabitacion + ", Cuidad=" +Cuidad + ", DescripcionDelahabitacion=" + DescripcionDelaHabitacion + ", Direccion=" + Direccion + ",Reservacion="+reservaciones+"]";
	}

  
}
