/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.administradorhotelero.administradorhotelero;

import com.mycompany.administradorhotelero.Entidades.Entidades.Habitacion;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

/**
 *
 * @author Lenovo
 */
public class HabitacionJpaController {
    private final EntityManagerFactory emf;

   public HabitacionJpaController(EntityManagerFactory emf) {
      this.emf=emf; 
    }

    public HabitacionJpaController() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("entidadesJPAPU");
        this.emf = emf;
    }  
    
    public EntityManager getEntityManager(){
    return emf.createEntityManager();
    
    }

    public void createHabitacion(Habitacion habitacion) {
      EntityManager em =null;
     try{
     em = getEntityManager();
     em.getTransaction().begin();
     em.persist(habitacion);
     em.getTransaction().commit();
     }finally{
     if(em!=null){
     em.close();
     }
    }
   
    }

    public void destroyHabitacion(int IdHabitacion) throws Exception{
       EntityManager em = null;
        try{
        em = getEntityManager();
        em.getTransaction().begin();
        Habitacion habitacion;
        try{
        habitacion=em.getReference(Habitacion.class, IdHabitacion);
        habitacion.getIdHabitacion();
        }catch (EntityNotFoundException enfe){
            throw new Exception("la habitacion con  id "+IdHabitacion+"no se encuentra habil o es inexistente ");
        }
        em.remove(habitacion);
        em.getTransaction().commit();
        }finally{
        if(em!=null){
        em.close();
        }  
    }
    }

    public void editarHabitacion(Habitacion habitacion)throws Exception  {
         EntityManager em =null;
        try{
        em =getEntityManager();
        em.getTransaction().begin();
        habitacion =em.merge(habitacion);
        em.getTransaction().commit();
        }catch(Exception ex ){
        String msg =ex.getLocalizedMessage();
        if(msg == null ||msg.length()==0){
        int id =habitacion.getIdHabitacion();
                  }
        
        }finally{
        if(em!=null){
        em.close();
        }
        }
    }

    public Habitacion traerHabitacion(int IdHabitacion) {
      EntityManager em = getEntityManager(); // Obtiene el EntityManager
    try {
        return em.find(Habitacion.class, IdHabitacion); // Utiliza el método find para buscar el habitacion por su ID
    } catch (Exception ex) {
        // Manejar la excepción apropiadamente
        ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
        return null; // O devuelve un hotel nulo o lanza una excepción personalizada
    } finally {
        if (em != null && em.isOpen()) {
            em.close(); // Asegúrate de cerrar el EntityManager si está abierto
        }
    }  
    }

    public List<Habitacion> listarHabitacion() {
        return findHabitacion(true,-1,-1);
    }

    private List<Habitacion> findHabitacion(boolean all, int maximo, int minimo) {
        EntityManager em = getEntityManager(); // Obtener el EntityManager

        try {
            CriteriaQuery<Habitacion> cq = (CriteriaQuery<Habitacion>) em.getCriteriaBuilder().createQuery(Habitacion.class);
            Root<Habitacion> root = (Root<Habitacion>) cq.from(Habitacion.class);
            cq.select((Selection<? extends Habitacion>) root);

            if (!all) {
                // Si no es necesario obtener todos los hoteles, aplica paginación
                Query q = em.createQuery(cq);
                q.setMaxResults(maximo);
                q.setFirstResult(minimo);
                return q.getResultList();
            } else {
                // Si se necesitan todos los hoteles
                return em.createQuery(cq).getResultList();
            }
        } catch (Exception ex) {
            // Manejar la excepción apropiadamente
            ex.printStackTrace(); // Esto solo imprime la excepción, puedes manejarla de otra manera según tu necesidad
            return null; // O devuelve una lista vacía o lanza una excepción personalizada
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Asegúrate de cerrar el EntityManager si está abierto
            }
        }

    }

   
    
}
